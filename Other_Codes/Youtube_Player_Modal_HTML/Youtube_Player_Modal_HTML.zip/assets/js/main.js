/**
 * Main JavaScript file for the WordPres theme
 *
 * This file gets loaded for all users.
 *
 * @license		No license
 * (Without a license, the code is copyrighted by default.
 * People can read the code, but they have no legal right to use
 * it. To use the code, you must contact the author directly and
 * ask permission.)
 *
 * @author		Velten Media
 * @link		http://www.veltenmedia.nl
 * @email		info@veltenmedia.nl
 *
 * @file		main.js
 *
 * @copyright	(C) 2015, Velten Media
 */

jQuery(document).ready(function($){
	
	$(function() {
		
		var $video_id;
		var player;
		
		
		function loadPlayer() {
			if (typeof(YT) == 'undefined' || typeof(YT.Player) == 'undefined') {
	
			    var tag = document.createElement('script');
			    tag.src = "https://www.youtube.com/iframe_api";
			    var firstScriptTag = document.getElementsByTagName('script')[0];
			    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
			
			} 
		}
		loadPlayer();
	
		function onYouTubePlayer() {
			// create the global player from the specific iframe (#video)
			
			if(player) {
				var curVideo = player.getVideoData()["video_id"];
				if ($video_id != curVideo){
					player.loadVideoById($video_id);
				} else {
					player.playVideo();
				}
			} else {
				player = new YT.Player('video-frame', {  
					videoId: $video_id,
					events: {
			        	'onReady': onPlayerReady
			        }
				}); 
			}
		}
		
		function onPlayerReady() {
			player.playVideo();
		}
		
		// Tile on click
		$('a.video-container').on('click', function() {
			$video_id = $(this).data('onclick-id');
			onYouTubePlayer();
		});
		
		// Close container
		$('.close-video').on('click', function() {
			if (player) {
				player.pauseVideo();
			}
			$('.video-left, .video-right').removeClass('open'); 
 		});
		
	});

	/* ********************
    Counter
    ******************** */
    var currentDate = new Date();
    var dateStr="2017-12-02 12:00";
    var a=dateStr.split(" ");
    var d=a[0].split("-");
    var t=a[1].split(":");
    var futureDate = new Date(d[0],(d[1]-1),d[2],t[0],t[1]);
    window.earlybirdTimestamp = parseInt(futureDate.getTime() / 1000 - currentDate.getTime() / 1000);

    var clock;

    clock = jQuery('.clock').FlipClock(window.earlybirdTimestamp, {
        clockFace: 'DailyCounter',
        countdown: true,
        autoStart: true,
        callbacks: {
            stop: function() {
                jQuery('.message').html('The clock has stopped!')
            }
        }
    });

	// Load on input and textarea elements if
	// the jQuery Placeholder plugin is loaded
	if($.isFunction($.fn.placeholder)){
		$('input, textarea').placeholder();
	}

/*
	$('.line-up-title').click(function(){
		$('.line-up-areas').toggleClass('open');
		$('.line-up-title').toggleClass('open');
	});
*/
	
	/* ************************
	Instafeed
	************************ */
	if(typeof Instafeed != 'undefined'){
		var instaFeed = new Instafeed({
	        get: 			'user',
	        userId: 		42050997,
	        accessToken: 	'42050997.a8df136.e8b0de67bacc49af8d95d74737b0c53e',
	        target: 		'instagram-feed',
	        sortBy: 		'most-recent',
	        limit: 			12,
	        resolution: 	'standard_resolution',
			template: 		'<div class="col-1-3"><div class="social-inner match"><a href="{{link}}" class="social-container" style="background:url({{image}})"><div class="likes-overlay"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" width="12px" height="12px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g><g><path d="M14.708,15.847C14.252,14.864,14,13.742,14,12.5s0.252-2.489,0.708-3.659c0.455-1.171,1.114-2.266,1.929-3.205 c0.814-0.938,1.784-1.723,2.86-2.271C20.574,2.814,21.758,2.5,23,2.5s2.426,0.252,3.503,0.707c1.077,0.456,2.046,1.115,2.86,1.929 c0.813,0.814,1.474,1.784,1.929,2.861C31.749,9.073,32,10.258,32,11.5s-0.252,2.427-0.708,3.503 c-0.455,1.077-1.114,2.047-1.929,2.861C28.55,18.678,17.077,29.044,16,29.5l0,0l0,0C14.923,29.044,3.45,18.678,2.636,17.864 c-0.814-0.814-1.473-1.784-1.929-2.861C0.252,13.927,0,12.742,0,11.5s0.252-2.427,0.707-3.503C1.163,6.92,1.821,5.95,2.636,5.136 C3.45,4.322,4.42,3.663,5.497,3.207C6.573,2.752,7.757,2.5,9,2.5s2.427,0.314,3.503,0.863c1.077,0.55,2.046,1.334,2.861,2.272 c0.814,0.939,1.473,2.034,1.929,3.205C17.748,10.011,18,11.258,18,12.5s-0.252,2.364-0.707,3.347 c-0.456,0.983-1.113,1.828-1.929,2.518" fill="#FFFFFF"/></g></g></svg><span> — {{likes}}</span></div><div class="social-overlay"><div class="caption">{{caption}}</div></div></a></div></div>'
		}).run();	
	}	


	$('#nav-btn').on('click', function(){
		$('.grid.mobilenav').toggleClass('open');
		$(this).toggleClass('open');
	});

	/* ********************
    Masonry
    ******************** */
/*
     var $container = $('#ms-container');
        $container.imagesLoaded( function() {
            $container.masonry({
                itemSelector: '.ms-item',
               columnWidth: '.ms-item',
				});
        });
*/
 
 	/* ********************
    Match height
    ******************** */       
    $('.match').matchHeight();
    
    
    /* ********************
    Video reveal
    ******************** */ 
    $('.video-container').on('click', function(){
		$('.video-left, .video-right').addClass('open'); 
 	});

/*
	jQuery(window).load(function() {
	  var container = document.querySelector('#ms-container');
	  var msnry = new Masonry( container, {
	    itemSelector: '.ms-item',
	    columnWidth: '.ms-item',
	});
*/
	
	setTimeout(function(){
		         
	$('a[href*="#"]:not([href="#"])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
	        || location.hostname == this.hostname) {
			
	        var target = $(this.hash); 
	        target = target.length ? target : $('[name=' + this.hash.slice(1) +']'); 
	           if (target.length) {
	             $('html,body').animate({
	                 scrollTop: target.offset().top
	            }, 1000);
	            return false;
	        }
	    }
	});
	
	}, 2000);



});

