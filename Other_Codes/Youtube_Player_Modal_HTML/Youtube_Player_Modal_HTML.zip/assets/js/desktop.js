/**
 * Desktop JavaScript file for the WordPres theme
 *
 * This file gets loaded for users browsing on desktop.
 *
 * @license		No license
 * (Without a license, the code is copyrighted by default.
 * People can read the code, but they have no legal right to use
 * it. To use the code, you must contact the author directly and
 * ask permission.)
 *
 * @author		Velten Media
 * @link		http://www.veltenmedia.nl
 * @email		info@veltenmedia.nl
 *
 * @file		desktop.js
 *
 * @copyright	(C) 2015, Velten Media
 */

jQuery(document).ready(function($){

	// do nothing

});