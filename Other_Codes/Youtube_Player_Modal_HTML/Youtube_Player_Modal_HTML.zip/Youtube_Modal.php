<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Youtube Modal</title>
    <link rel="shortcut icon" href="favicon.ico"/>
    <link rel="icon" href="favicon.ico"/>
    <meta charset="utf-8">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="https://use.typekit.net/gop5ggc.css">
    <meta name="theme-color" content="#0F0">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
    <meta name="description" content="Youtube Player Modal" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="Youtube Player Modal | Videos" />
    <meta property="og:description" content="Youtube Player Modal" />
    <meta property="og:site_name" content="Youtube Player Modal" />
    <meta property="article:publisher" content="https://www.facebook.com/albdroid.official" />
    <meta property="article:modified_time" content="2021-05-04T09:42:05+00:00" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@trc4com" />

<link rel="stylesheet" id="theme-style-css" href="assets/css/style.css" type="text/css" media="all" />

<script type="text/javascript" src="assets/plugins/jquery/jquery.min.js?ver=3.5.1" id="jquery-core-js"></script>
<script type="text/javascript" src="assets/plugins/jquery/jquery-migrate.min.js?ver=3.3.2" id="jquery-migrate-js"></script>

</head>
<!-- PLAYER BACKGROUND -->
<body class="page-template-default page page-id-20 elementor-default elementor-kit-1448" style="background: url(assets/images/bg.png); background-repeat: no-repeat; background-size: cover; background-position: center center;">

<header class="header">

	<div class="inner">
		<div id="nav-btn">
			<span></span>
			<span></span>
			<span></span>
		</div>
<!-- VOTE MENU -->
<!-- --/>
		<a href="/vote/" target="_blank" class="sxt_vote" id="sxt_vote">
		    <div class="img_wrapper">
		        <img src="assets/images/alb_logo.png" class="sxt_logo" alt="SXT logo">
		    </div>
		    <div class="vote_txt_wrapper">
		        <span>Vote me</span>
		        <span class="vote">Vote SXT</span>
		    </div>

		    <div class="outgoing_icon">
		        <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg">
		            <g fill="#000" fill-rule="nonzero">
		                <path d="M18.762 0h-6.875c-.68 0-1.232.553-1.232 1.232 0 .68.553 1.233 1.232 1.233h3.9L9.282 8.97c-.232.23-.362.544-.361.871 0 .33.128.64.36.872.231.232.545.362.872.36.33 0 .639-.127.872-.36l6.505-6.505v3.9c0 .679.553 1.232 1.232 1.232.68 0 1.233-.553 1.233-1.233V1.232c0-.68-.553-1.232-1.233-1.232z" />
		                <path d="M14.165 17.882H2.113V5.83h9.064l2.113-2.113H1.056C.473 3.717 0 4.19 0 4.774v14.164c0 .584.473 1.057 1.056 1.057h14.165c.583 0 1.056-.473 1.056-1.057V6.705l-2.112 2.113v9.064z" />
		            </g>
		        </svg>
		    </div>
		</a>
<!-- -->

</div>

<div class="grid mobilenav">
    <nav class="nav">
        <ul id="menu-hoofdmenu" class="menu">
<!-- NAV MENU -->
<!-- --/>
            <li id="menu-item-13" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-13">
			<a href="./">Home</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-1005" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1005">
			<a href="http://localhost/data/">Data</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-20 current_page_item menu-item-37">
			<a href="http://localhost/videos/" aria-current="page">Videos</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-1008" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1008">
			<a href="http://localhost/booking/">Booking</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-1200" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1200">
			<a href="http://localhost/newsletter/">Newsletter</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-1617" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1617">
			<a href="http://localhost/shop/">Shop</a>
			</li>
<!-- -->
<!-- --/>
            <li id="menu-item-1069" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1069">
			<a href="http://localhost/playlist/">► Playlist</a>
			</li>
<!-- -->
        </ul>
    </nav>
</div>
</header>

<div class="video-page">
	<div class="video-left col-1-2">

		<div class="video-wrapper col-1-1">

		    <a class="video-container" style="background:url(https://i.ytimg.com/vi/OfWMRiMNiFA/hqdefault.jpg);" href="#OfWMRiMNiFA" data-onclick-id="OfWMRiMNiFA">
		        <div class="video-overlay">
		            <div class="video-title">
		                Masters Of Hardcore - Pole Position 2008 (Live Registration) <div class="play-btn">
		                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 41.999 41.999" style="enable-background:new 0 0 41.999 41.999;" xml:space="preserve" width="30px" height="30px">
		                        <path d="M36.068,20.176l-29-20C6.761-0.035,6.363-0.057,6.035,0.114C5.706,0.287,5.5,0.627,5.5,0.999v40  c0,0.372,0.206,0.713,0.535,0.886c0.146,0.076,0.306,0.114,0.465,0.114c0.199,0,0.397-0.06,0.568-0.177l29-20  c0.271-0.187,0.432-0.494,0.432-0.823S36.338,20.363,36.068,20.176z" fill="#0F0" />
		                    </svg>
		                </div>
		            </div>
		        </div>
		    </a>
		</div>

		<div class="video-wrapper col-1-1">

		    <a class="video-container" style="background:url(https://i.ytimg.com/vi/OYfG9XKm7n4/hqdefault.jpg);" href="#OYfG9XKm7n4" data-onclick-id="OYfG9XKm7n4">
		        <div class="video-overlay">
		            <div class="video-title">
		                Nightmare Outdoor - Offensive Vs The Hitman <div class="play-btn">
		                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 41.999 41.999" style="enable-background:new 0 0 41.999 41.999;" xml:space="preserve" width="30px" height="30px">
		                        <path d="M36.068,20.176l-29-20C6.761-0.035,6.363-0.057,6.035,0.114C5.706,0.287,5.5,0.627,5.5,0.999v40  c0,0.372,0.206,0.713,0.535,0.886c0.146,0.076,0.306,0.114,0.465,0.114c0.199,0,0.397-0.06,0.568-0.177l29-20  c0.271-0.187,0.432-0.494,0.432-0.823S36.338,20.363,36.068,20.176z" fill="#0F0" />
		                    </svg>
		                </div>
		            </div>
		        </div>
		    </a>
		</div>
		</div>

	<div class="video-right col-1-2">
		<div class="video-wrapper col-1-1">
		    <a class="video-container" style="background:url(https://i.ytimg.com/vi/g838e3Ra1Ko/hqdefault.jpg);" href="#g838e3Ra1Ko" data-onclick-id="g838e3Ra1Ko">

		        <div class="video-overlay">
		            <div class="video-title">
		                Nightmare - Create The Future <div class="play-btn">
		                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 41.999 41.999" style="enable-background:new 0 0 41.999 41.999;" xml:space="preserve" width="30px" height="30px">
		                        <path d="M36.068,20.176l-29-20C6.761-0.035,6.363-0.057,6.035,0.114C5.706,0.287,5.5,0.627,5.5,0.999v40  c0,0.372,0.206,0.713,0.535,0.886c0.146,0.076,0.306,0.114,0.465,0.114c0.199,0,0.397-0.06,0.568-0.177l29-20  c0.271-0.187,0.432-0.494,0.432-0.823S36.338,20.363,36.068,20.176z" fill="#0F0" />
		                    </svg>
		                </div>
		            </div>
		        </div>
		    </a>
		</div>

		<div class="video-wrapper col-1-1">
		    <a class="video-container" style="background:url(https://i.ytimg.com/vi/Sqc_7fACer0/hqdefault.jpg);" href="#Sqc_7fACer0" data-onclick-id="Sqc_7fACer0">

		        <div class="video-overlay">
		            <div class="video-title">
		                The Prodigy - No Good (Re-Style Bootleg) <div class="play-btn">
		                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 41.999 41.999" style="enable-background:new 0 0 41.999 41.999;" xml:space="preserve" width="30px" height="30px">
		                        <path d="M36.068,20.176l-29-20C6.761-0.035,6.363-0.057,6.035,0.114C5.706,0.287,5.5,0.627,5.5,0.999v40  c0,0.372,0.206,0.713,0.535,0.886c0.146,0.076,0.306,0.114,0.465,0.114c0.199,0,0.397-0.06,0.568-0.177l29-20  c0.271-0.187,0.432-0.494,0.432-0.823S36.338,20.363,36.068,20.176z" fill="#0F0" />
		                    </svg>
		                </div>
		            </div>
		        </div>
		    </a>
		</div> 
		
</div>

	<div class="video-player-wrapper" id="mobile">
	    <div class="auto-size-container">
	        <div class="video-box">
	            <div class="close-video"></div>
	            <div id="video-frame" class="iframe-div"></div>
	        </div>
	    </div>
	</div>

</div>

<footer class="footer">
	<div class="footer-social fr">
	<ul>
		<li>
		<a href="https://www.facebook.com/albdroid.official" target="_blank">
		<svg class="social-icons" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			 viewBox="0 0 408.788 408.788" style="enable-background:new 0 0 408.788 408.788;" xml:space="preserve">
		<path d="M353.701,0H55.087C24.665,0,0.002,24.662,0.002,55.085v298.616c0,30.423,24.662,55.085,55.085,55.085
			h147.275l0.251-146.078h-37.951c-4.932,0-8.935-3.988-8.954-8.92l-0.182-47.087c-0.019-4.959,3.996-8.989,8.955-8.989h37.882
			v-45.498c0-52.8,32.247-81.55,79.348-81.55h38.65c4.945,0,8.955,4.009,8.955,8.955v39.704c0,4.944-4.007,8.952-8.95,8.955
			l-23.719,0.011c-25.615,0-30.575,12.172-30.575,30.035v39.389h56.285c5.363,0,9.524,4.683,8.892,10.009l-5.581,47.087
			c-0.534,4.506-4.355,7.901-8.892,7.901h-50.453l-0.251,146.078h87.631c30.422,0,55.084-24.662,55.084-55.084V55.085
			C408.786,24.662,384.124,0,353.701,0z"/>
		<g>
		</svg>
		</a>
		</li>

		<li>
		<a href="https://www.instagram.com/albdroid.al/" target="_blank">
			<svg class="social-icons" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 viewBox="0 0 551.034 551.034" style="enable-background:new 0 0 551.034 551.034;" xml:space="preserve">
			<g>
				<path d="M386.878,0H164.156C73.64,0,0,73.64,0,164.156v222.722
					c0,90.516,73.64,164.156,164.156,164.156h222.722c90.516,0,164.156-73.64,164.156-164.156V164.156
					C551.033,73.64,477.393,0,386.878,0z M495.6,386.878c0,60.045-48.677,108.722-108.722,108.722H164.156
					c-60.045,0-108.722-48.677-108.722-108.722V164.156c0-60.046,48.677-108.722,108.722-108.722h222.722
					c60.045,0,108.722,48.676,108.722,108.722L495.6,386.878L495.6,386.878z"/>
				<path  d="M275.517,133C196.933,133,133,196.933,133,275.516
					s63.933,142.517,142.517,142.517S418.034,354.1,418.034,275.516S354.101,133,275.517,133z M275.517,362.6
					c-48.095,0-87.083-38.988-87.083-87.083s38.989-87.083,87.083-87.083c48.095,0,87.083,38.988,87.083,87.083
					C362.6,323.611,323.611,362.6,275.517,362.6z"/>
				<circle cx="418.306" cy="134.072" r="34.149"/>
			</g>
			</svg>
		</a>
		</li>

		<li>
		<a href="https://soundcloud.com/sxtbox" target="_blank">
			<svg class="social-icons" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 viewBox="0 0 291.319 291.319" style="enable-background:new 0 0 291.319 291.319;" xml:space="preserve">
			<g>
				<path d="M72.83,218.485h18.207V103.832c-6.828,1.93-12.982,5.435-18.207,10.041
					C72.83,113.874,72.83,218.485,72.83,218.485z M36.415,140.921v77.436l1.174,0.127h17.033v-77.682H37.589
					C37.589,140.803,36.415,140.921,36.415,140.921z M0,179.63c0,14.102,7.338,26.328,18.207,33.147V146.52
					C7.338,153.329,0,165.556,0,179.63z M109.245,218.485h18.207v-109.6c-5.444-3.396-11.607-5.635-18.207-6.5V218.485z
					 M253.73,140.803h-10.242c0.519-3.168,0.847-6.382,0.847-9.705c0-32.182-25.245-58.264-56.388-58.264
					c-16.896,0-31.954,7.775-42.287,19.955v125.695h108.07c20.747,0,37.589-17.388,37.589-38.855
					C291.319,158.182,274.477,140.803,253.73,140.803z"/>
			</g>
			</svg>
		</a>
		</li>

		<li>
		<a href="https://www.youtube.com/TRC4Deejay" target="_blank">
			<svg class="social-icons" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 viewBox="0 0 461.001 461.001" style="enable-background:new 0 0 461.001 461.001;" xml:space="preserve">
			<g>
				<path d="M365.257,67.393H95.744C42.866,67.393,0,110.259,0,163.137v134.728
					c0,52.878,42.866,95.744,95.744,95.744h269.513c52.878,0,95.744-42.866,95.744-95.744V163.137
					C461.001,110.259,418.135,67.393,365.257,67.393z M300.506,237.056l-126.06,60.123c-3.359,1.602-7.239-0.847-7.239-4.568V168.607
					c0-3.774,3.982-6.22,7.348-4.514l126.06,63.881C304.363,229.873,304.298,235.248,300.506,237.056z"/>
			</g>
			</svg>
		</a>
		</li>

		<li>
		<a href="https://twitter.com/trc4com" target="_blank">
			<svg class="social-icons" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 viewBox="0 0 410.155 410.155" style="enable-background:new 0 0 410.155 410.155;" xml:space="preserve">
			<path d="M403.632,74.18c-9.113,4.041-18.573,7.229-28.28,9.537c10.696-10.164,18.738-22.877,23.275-37.067
				l0,0c1.295-4.051-3.105-7.554-6.763-5.385l0,0c-13.504,8.01-28.05,14.019-43.235,17.862c-0.881,0.223-1.79,0.336-2.702,0.336
				c-2.766,0-5.455-1.027-7.57-2.891c-16.156-14.239-36.935-22.081-58.508-22.081c-9.335,0-18.76,1.455-28.014,4.325
				c-28.672,8.893-50.795,32.544-57.736,61.724c-2.604,10.945-3.309,21.9-2.097,32.56c0.139,1.225-0.44,2.08-0.797,2.481
				c-0.627,0.703-1.516,1.106-2.439,1.106c-0.103,0-0.209-0.005-0.314-0.015c-62.762-5.831-119.358-36.068-159.363-85.14l0,0
				c-2.04-2.503-5.952-2.196-7.578,0.593l0,0C13.677,65.565,9.537,80.937,9.537,96.579c0,23.972,9.631,46.563,26.36,63.032
				c-7.035-1.668-13.844-4.295-20.169-7.808l0,0c-3.06-1.7-6.825,0.485-6.868,3.985l0,0c-0.438,35.612,20.412,67.3,51.646,81.569
				c-0.629,0.015-1.258,0.022-1.888,0.022c-4.951,0-9.964-0.478-14.898-1.421l0,0c-3.446-0.658-6.341,2.611-5.271,5.952l0,0
				c10.138,31.651,37.39,54.981,70.002,60.278c-27.066,18.169-58.585,27.753-91.39,27.753l-10.227-0.006
				c-3.151,0-5.816,2.054-6.619,5.106c-0.791,3.006,0.666,6.177,3.353,7.74c36.966,21.513,79.131,32.883,121.955,32.883
				c37.485,0,72.549-7.439,104.219-22.109c29.033-13.449,54.689-32.674,76.255-57.141c20.09-22.792,35.8-49.103,46.692-78.201
				c10.383-27.737,15.871-57.333,15.871-85.589v-1.346c-0.001-4.537,2.051-8.806,5.631-11.712c13.585-11.03,25.415-24.014,35.16-38.591
				l0,0C411.924,77.126,407.866,72.302,403.632,74.18L403.632,74.18z"/>
			<g>
			</svg>
		</a>
		</li>
		
	</ul>
</div>

	<div class="grid">
		<div class="footer-content">
			<p>&copy; 2020 - 2021 ( <a href="https://trc4.com" target="_blank"><strong>TRC4.COM</strong></a> - <a href="https://kodi.al" target="_blank"><strong>KODI.AL</strong></a> )</p>
		</div>
	</div>
</footer>

<button type="button" class="pum-close popmake-close" aria-label="Close">×</button>
</div>

</div>

<!--[if lt IE 10]><script src="assets/js/vendor/jquery.placeholder-2.1.1.min.js"></script><![endif]-->

<script type="text/javascript" src="assets/js/vendor/jquery-match-height/jquery.matchHeight-min.js?ver=1.0" id="match-height-js"></script>

<script type="text/javascript" src="assets/js/vendor/flipclock.min.js?ver=1.0" id="flipclock-js"></script>
<!----/>
<script type="text/javascript" src="assets/js/imagesloaded.js?ver=4.1.4" id="imagesloaded-js"></script>
<!---->
<!---->
<script type="text/javascript" src="assets/js/masonry.min.js?ver=4.2.2" id="masonry-js"></script>
<!---->
<script type="text/javascript" src="assets/js/vendor/jquery.youtubebackground.js?ver=1.0" id="youtubebackground-js"></script>

<script type="text/javascript" src="assets/js/vendor/jquery-match-height/jquery.matchHeight-min.js?ver=1.0" id="matchHeight-js"></script>

<script type="text/javascript" src="assets/js/main.js?ver=1.0" id="vm-main-js-js"></script>

<script type="text/javascript" src="assets/js/desktop.js?ver=1.0" id="vm-desktop-js-js"></script>

<script type="text/javascript" src="assets/js/vendor/wp-polyfill.min.js?ver=7.4.4" id="wp-polyfill-js"></script>

<script type="text/javascript" src="assets/plugins/jquery/ui/core.min.js?ver=1.12.1" id="jquery-ui-core-js"></script>


<script type="text/javascript" src="assets/plugins/embeder/embed.js?ver=5.7.2" id="embed-js"></script>

</body>


</html>  